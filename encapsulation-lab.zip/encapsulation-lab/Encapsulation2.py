class Email_Validator:
    def __init__(self, min_length, mails, domains):
        self.min_length = min_length
        self.mails = mails
        self.domains = domains
    def validate_name(self, name):
        self.name = name
        if self.name >= self.min_length:
            return True
        else:
            return False
    def validate_mail(self, mail):
        self.mail = mail
        if self.mail in self.mails:
            return True
        else:
            return False
    def validate_domain(self, domain):
        self.domain = domain
        if self.domain in self.domains:
            return True
        else:
            return False
    def validate(self, mail):
        if"@" not in mail:
            return False
        parts = mail.split("@")
        if len(parts) != 2:
            return False
        name, domain = parts
        domain_parts = domain.split(".")
        if len(domain_parts) != 2:
            return False
        return(
            self.validate_name(name)
            and self.validate_mail(domain_parts[0])
            and self.validate_domain(domain_parts[1])
        )
mails = ["gmail", "softuni"]
domains = ["com", "bg"]
email_validator = Email_Validator(6, mails, domains)
print(email_validator.validate("pe77er@gmail.com"))